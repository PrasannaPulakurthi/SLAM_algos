#include "ros/ros.h"
#include "nav_msgs/Odometry.h"
#include "geometry_msgs/Twist.h"
#include "geometry_msgs/Quaternion.h"
#include "tf/tf.h"

using namespace std;


class robot{
    public:
    double cur_x, cur_y;
    double roll, pitch, yaw;
    geometry_msgs::Quaternion ori;
    double x = 5, y = 5;
    geometry_msgs::Twist move;
    void callback(const nav_msgs::Odometry::ConstPtr& msg)
    {
        cur_x = msg->pose.pose.position.x;
        cur_y = msg->pose.pose.position.y;
        ori = msg->pose.pose.orientation;
        tf::Quaternion q(ori.x, ori.y, ori.z, ori.w);
        tf::Matrix3x3 m(q);
        m.getRPY(roll, pitch, yaw);
        //cout << "yaw" << ":" << yaw << endl;
    }

    void fun(){
        float diff_x = x - cur_x;
        float diff_y = y - cur_y;
        double theta = atan2(diff_y, diff_x);
        cout << "diff" << abs(yaw - theta) << endl;
        if(abs(yaw - theta) > 0.1){
            move.angular.z = 0.3;
            move.linear.x = 0.0;
        }
        else{
            //cout << "inside" << endl;
            move.linear.x = 0.3;
            move.angular.z = 0.0;
        }
        p.publish(move);
    }


    ros::NodeHandle n;
    ros::Subscriber sub = n.subscribe("/odom", 1, &robot::callback, this);
    ros::Publisher p = n.advertise<geometry_msgs::Twist>("/cmd_vel", 1);

    
    
};


int main(int argc, char **argv)
{
    bool a = ros::ok();
    cout << a << endl;
    ros::init(argc, argv, "test");
    robot r;
    ros::Rate loop_rate(1);
    
    while(ros::ok())
    {
        ros::spinOnce();
        r.fun();
        loop_rate.sleep();   
    }
    
    
    return 0;
}