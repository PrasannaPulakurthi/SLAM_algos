#!/usr/bin/env python

import sys
import rospy
from nav_msgs.msg import Odometry
from tf.transformations import euler_from_quaternion
from geometry_msgs.msg import Twist
from math import atan2


class rosbot():
    def __init__(self, q, w):
        #rospy.init_node('controller')
        rospy.Subscriber('/odom', Odometry, self.callback)
        self.p = rospy.Publisher('/cmd_vel', Twist, queue_size=1)
        self.a = 0
        self.b = 0
        self.goal = (q, w)
        self.temp = Twist()
        self.rate = rospy.Rate(2)
        self.theta = 0
    
    def callback(self, msg):
        self.a = msg.pose.pose.position.x
        self.b = msg.pose.pose.position.y
        self.rot = msg.pose.pose.orientation
        self.roll, self.pitch, self.theta = euler_from_quaternion([self.rot.x, self.rot.y, self.rot.z, self.rot.w])

    def printf(self):
        print(self.a)
        
    def math_func(self):
        self.x = self.goal[0] - self.a
        self.y = self.goal[1] - self.b
        self.angle = atan2(self.y, self.x)
        if abs(self.angle - self.theta) > 0.1:
            self.temp.angular.z = 0.3
            self.temp.linear.x = 0.0
        else:
            self.temp.linear.x = 0.3
            self.temp.angular.z = 0.0
        
            

    def publish(self):
        print "close_x" + " " + str(abs(self.a - self.goal[0])) + " " + "close_y" + str(abs(self.b - self.goal[1]))
        if (abs(self.a - self.goal[0])) < 0.1 and abs(self.b - self.goal[1]) < 0.1:
            self.temp.angular.z = 0.0
            self.temp.linear.x = 0.0
            self.p.publish(self.temp)
            print "stop"
        else:
            self.p.publish(self.temp)

        

if __name__ == "__main__":
    rospy.init_node('IK')
    robot = rosbot(int(sys.argv[1]), int(sys.argv[2]))
    while not rospy.is_shutdown():
        robot.math_func()
        robot.publish()
        rospy.sleep(0.1)
    
