#include <iostream>
#include "ros/ros.h"
#include "geometry_msgs/Twist.h"
#include "nav_msgs/Odometry.h"
#include "math.h"
#include "geometry_msgs/Quaternion.h"
#include "tf/tf.h"
#include <unistd.h>

using namespace std;

class robot{
    public:
    float x, y;
    float cur_x, cur_y;
    geometry_msgs::Quaternion ori;
    double roll, pitch, yaw;
    geometry_msgs::Twist move;
    ros::Publisher p;

    robot(float X, float Y){
        x = x;
        y = Y;
        ros::NodeHandle nh;
        p = nh.advertise<geometry_msgs::Twist>("/cmd_vel", 1);
        ros::Subscriber sub = nh.subscribe("/odom", 1, &robot::callback, this);
    }

    void callback(const nav_msgs::Odometry::ConstPtr& msg)
    {
        cur_x = msg->pose.pose.position.x;
        cur_y = msg->pose.pose.position.y;
        ori = msg->pose.pose.orientation;
        tf::Quaternion q(ori.x, ori.y, ori.z, ori.w);
        tf::Matrix3x3 m(q);
        m.getRPY(roll, pitch, yaw);
    }

    
    geometry_msgs::Twist mathfunc(){
        float diff_x = x - cur_x;
        float diff_y = y - cur_y;
        double theta = atan2(diff_y, diff_x);
        cout << abs(yaw - theta) << endl;
        if(abs(yaw - theta) > 0.1){
            cout << "inside" << endl;
            move.angular.z = 0.3;
            move.linear.x = 0.0;
        }
        else{
            move.linear.x = 0.3;
            move.angular.z = 0.0;
        }
        cout << "hello" << endl;
        return move;

    }
    

};




int main(int argc, char **argv){
    geometry_msgs::Twist temp;
    ros::init(argc, argv, "inverse_kinematics");
    robot r(5, 5);
    ros::spin();
    ros::Rate loop_rate(10);
    
    bool a = ros::ok();
    cout << a;

    for(;;){
        temp = r.mathfunc();
        r.p.publish(temp);
        sleep(1);
    }
    return 0;
}