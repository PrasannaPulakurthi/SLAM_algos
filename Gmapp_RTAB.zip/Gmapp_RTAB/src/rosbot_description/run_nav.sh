#!/bin/bash

roslaunch rosbot_navigation amcl_demo.launch
